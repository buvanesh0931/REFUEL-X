const express = require('express')
const User = require( '../models/User.js')

const router = express.Router()

router.post('/login', async (req, res) => {
  const { email, password, location } = req.body
  let user = await User.findOne({ email })

  if (!user) {
    user = new User({ email, password, location })
    await user.save()
    return res.json({ msg: 'User created and logged in', user })
  }

  if (user.password !== password) {
    return res.status(401).json({ msg: 'Invalid credentials' })
  }

  user.location = location
  await user.save()

  res.json({ msg: 'Login successful', user })
})


